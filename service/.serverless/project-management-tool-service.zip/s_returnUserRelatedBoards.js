
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'blitzblade',
  applicationName: 'project-management-tool-service',
  appUid: 'Fkmrn5SV5gD8p8L6w6',
  orgUid: '3148483a-baf9-4277-a320-e41bdaf43835',
  deploymentUid: '112234a5-c16a-4d07-9f9a-90ea8f40b44f',
  serviceName: 'project-management-tool-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'project-management-tool-service-dev-returnUserRelatedBoards', timeout: 6 };

try {
  const userHandler = require('./handlers/board.js');
  module.exports.handler = serverlessSDK.handler(userHandler.boards, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}